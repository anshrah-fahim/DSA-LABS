#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prev;
};

Node* head = NULL;

// Display function
void display() {
    if (head == NULL) {
        cout << "\nList is empty!\n";
        return;
    }
    Node* temp = head;
    cout << "\nCircular Doubly Linked List: ";
    do {
        cout << temp->data << " <-> ";
        temp = temp->next;
    } while (temp != head);
    cout << "(back to head)\n";
}

// Insert at End (helper function)
void insertAtEnd(int value) {
    Node* newNode = new Node();
    newNode->data = value;

    if (head == NULL) {
        newNode->next = newNode;
        newNode->prev = newNode;
        head = newNode;
    } else {
        Node* last = head->prev;
        newNode->next = head;
        newNode->prev = last;
        last->next = newNode;
        head->prev = newNode;
    }
}

// Insert After a Given Node
void insertAfterValue(int location, int value) {
    if (head == NULL) {
        cout << "\nList is empty! Cannot insert.";
        return;
    }

    Node* temp = head;
    bool found = false;
    do {
        if (temp->data == location) {
            found = true;
            break;
        }
        temp = temp->next;
    } while (temp != head);

    if (!found) {
        cout << "\nNode with value " << location << " not found!";
        return;
    }

    Node* newNode = new Node();
    newNode->data = value;

    Node* temp2 = temp->next;
    temp->next = newNode;
    newNode->prev = temp;
    newNode->next = temp2;
    temp2->prev = newNode;

    cout << "\nInserted " << value << " after node with value " << location << ".";
}

int main() {
    insertAtEnd(10);
    insertAtEnd(20);
    insertAtEnd(30);
    display();

    insertAfterValue(20, 25);
    insertAfterValue(10, 15);
    display();
    return 0;
}
