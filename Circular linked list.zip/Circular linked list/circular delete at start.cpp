#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* head = NULL;

// Function to display the list
void display() {
    if (head == NULL) {
        cout << "\nList is empty!";
        return;
    }
    Node* temp = head;
    cout << "\nCircular Linked List: ";
    do {
        cout << temp->data << " -> ";
        temp = temp->next;
    } while (temp != head);
    cout << "(back to head)\n";
}

// Delete node from the beginning
void deleteAtBeginning() {
    if (head == NULL) {
        cout << "\nList is empty! Deletion not possible.";
        return;
    }

    Node* temp = head;

    // Only one node case
    if (head->next == head) {
        delete head;
        head = NULL;
        cout << "\nDeleted the only node in the list.";
        return;
    }

    // Move to last node
    Node* last = head;
    while (last->next != head)
        last = last->next;

    // Adjust links
    last->next = head->next;
    head = head->next;

    delete temp;
    cout << "\nDeleted node from beginning.";
}

int main() {
    // Create sample list manually
    Node* n1 = new Node{10, NULL};
    Node* n2 = new Node{20, NULL};
    Node* n3 = new Node{30, NULL};
    n1->next = n2;
    n2->next = n3;
    n3->next = n1;
    head = n1;

    display();
    deleteAtBeginning();
    display();
    return 0;
}
