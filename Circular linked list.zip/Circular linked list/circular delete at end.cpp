#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* head = NULL;

// Function to display the list
void display() {
    if (head == NULL) {
        cout << "\nList is empty!";
        return;
    }
    Node* temp = head;
    cout << "\nCircular Linked List: ";
    do {
        cout << temp->data << " -> ";
        temp = temp->next;
    } while (temp != head);
    cout << "(back to head)\n";
}

// Delete node from the end
void deleteAtEnd() {
    if (head == NULL) {
        cout << "\nList is empty! Deletion not possible.";
        return;
    }

    // Only one node case
    if (head->next == head) {
        delete head;
        head = NULL;
        cout << "\nDeleted the only node in the list.";
        return;
    }

    Node* temp = head;
    Node* prev = NULL;

    // Move to last node
    while (temp->next != head) {
        prev = temp;
        temp = temp->next;
    }

    prev->next = head;
    delete temp;

    cout << "\nDeleted node from end.";
}

int main() {
    // Create sample list manually
    Node* n1 = new Node{10, NULL};
    Node* n2 = new Node{20, NULL};
    Node* n3 = new Node{30, NULL};
    n1->next = n2;
    n2->next = n3;
    n3->next = n1;
    head = n1;

    display();
    deleteAtEnd();
    display();
    return 0;
}
