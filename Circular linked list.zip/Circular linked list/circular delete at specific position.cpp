#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* head = NULL;

// Function to display the list
void display() {
    if (head == NULL) {
        cout << "\nList is empty!";
        return;
    }
    Node* temp = head;
    cout << "\nCircular Linked List: ";
    do {
        cout << temp->data << " -> ";
        temp = temp->next;
    } while (temp != head);
    cout << "(back to head)\n";
}

// Delete node at specific position (1-based index)
void deleteAtPosition(int pos) {
    if (head == NULL) {
        cout << "\nList is empty! Deletion not possible.";
        return;
    }

    Node* temp = head;

    // Deleting the first node
    if (pos == 1) {
        if (head->next == head) {
            delete head;
            head = NULL;
            cout << "\nDeleted the only node.";
            return;
        }

        Node* last = head;
        while (last->next != head)
            last = last->next;

        head = head->next;
        last->next = head;
        delete temp;
        cout << "\nDeleted node at position " << pos << ".";
        return;
    }

    // Traverse to the (pos-1)th node
    Node* prev = NULL;
    for (int i = 1; i < pos; i++) {
        prev = temp;
        temp = temp->next;

        // If position exceeds list length
        if (temp == head) {
            cout << "\nInvalid position!";
            return;
        }
    }

    prev->next = temp->next;
    delete temp;
    cout << "\nDeleted node at position " << pos << ".";
}

int main() {
    // Create sample list manually
    Node* n1 = new Node{10, NULL};
    Node* n2 = new Node{20, NULL};
    Node* n3 = new Node{30, NULL};
    Node* n4 = new Node{40, NULL};
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = n1;
    head = n1;

    display();
    deleteAtPosition(3);
    display();
    return 0;
}
