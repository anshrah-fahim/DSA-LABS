#include <iostream>
#include <string>
using namespace std;

// ?? Structure for each player node
struct Player {
    string name;
    int score;
    Player* next;
    Player* prev;
};

Player* head = NULL;

// ?? Function to create a new node
Player* createNode(string name, int score) {
    Player* newNode = new Player();
    newNode->name = name;
    newNode->score = score;
    newNode->next = newNode->prev = NULL;
    return newNode;
}

// ?? Add new player in sorted order (ascending score)
void addPlayer(string name, int score) {
    Player* newNode = createNode(name, score);

    if (head == NULL) {
        head = newNode;
        return;
    }

    // If new player has lower score than head
    if (score < head->score) {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
        return;
    }

    Player* temp = head;
    while (temp->next != NULL && temp->next->score <= score)
        temp = temp->next;

    newNode->next = temp->next;
    if (temp->next != NULL)
        temp->next->prev = newNode;
    temp->next = newNode;
    newNode->prev = temp;
}

// ?? Delete player by name
void deletePlayer(string name) {
    if (head == NULL) {
        cout << "List is empty!\n";
        return;
    }

    Player* temp = head;
    while (temp != NULL && temp->name != name)
        temp = temp->next;

    if (temp == NULL) {
        cout << "Player not found!\n";
        return;
    }

    if (temp->prev != NULL)
        temp->prev->next = temp->next;
    else
        head = temp->next;

    if (temp->next != NULL)
        temp->next->prev = temp->prev;

    delete temp;
    cout << "Player '" << name << "' deleted successfully!\n";
}

// ?? Display all players (ascending order)
void displayAll() {
    if (head == NULL) {
        cout << "No players in list.\n";
        return;
    }

    Player* temp = head;
    cout << "\n??? Player List (Ascending by Score):\n";
    while (temp != NULL) {
        cout << "Name: " << temp->name << ", Score: " << temp->score << endl;
        temp = temp->next;
    }
}

// ?? Display all players in descending order
void displayDescending() {
    if (head == NULL) {
        cout << "List is empty!\n";
        return;
    }

    Player* temp = head;
    while (temp->next != NULL)
        temp = temp->next;

    cout << "\n?? Player List (Descending by Score):\n";
    while (temp != NULL) {
        cout << "Name: " << temp->name << ", Score: " << temp->score << endl;
        temp = temp->prev;
    }
}

// ?? Display player(s) with lowest score
void displayLowestScore() {
    if (head == NULL) {
        cout << "List is empty!\n";
        return;
    }

    int lowest = head->score;
    cout << "\n? Players with the lowest score (" << lowest << "):\n";
    Player* temp = head;
    while (temp != NULL && temp->score == lowest) {
        cout << temp->name << endl;
        temp = temp->next;
    }
}

// ?? Display all players having same score entered by user
void displaySameScore(int score) {
    if (head == NULL) {
        cout << "List is empty!\n";
        return;
    }

    bool found = false;
    Player* temp = head;
    cout << "\nPlayers with score " << score << ":\n";
    while (temp != NULL) {
        if (temp->score == score) {
            cout << "Name: " << temp->name << endl;
            found = true;
        }
        temp = temp->next;
    }
    if (!found)
        cout << "No players found with this score.\n";
}

// ?? Display players backward from a given player
void displayBackwardFrom(string name) {
    Player* temp = head;
    while (temp != NULL && temp->name != name)
        temp = temp->next;

    if (temp == NULL) {
        cout << "Player not found!\n";
        return;
    }

    cout << "\n?? Players before " << name << ":\n";
    temp = temp->prev;
    if (temp == NULL)
        cout << "No players before " << name << ".\n";
    else {
        while (temp != NULL) {
            cout << "Name: " << temp->name << ", Score: " << temp->score << endl;
            temp = temp->prev;
        }
    }
}

// ?? Main Menu
int main() {
    int choice, score;
    string name;

    do {
        cout << "\n-----------------------------------------";
        cout << "\n??? GOLF TOURNAMENT SCORE SYSTEM ???";
        cout << "\n1. Add New Player";
        cout << "\n2. Delete Player";
        cout << "\n3. Display All Players (Ascending)";
        cout << "\n4. Display All Players (Descending)";
        cout << "\n5. Display Player(s) with Lowest Score";
        cout << "\n6. Display All Players with Same Score";
        cout << "\n7. Display Backward from a Player";
        cout << "\n0. Exit";
        cout << "\n-----------------------------------------";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter player name: ";
                cin >> name;
                cout << "Enter player score: ";
                cin >> score;
                addPlayer(name, score);
                break;
            case 2:
                cout << "Enter player name to delete: ";
                cin >> name;
                deletePlayer(name);
                break;
            case 3:
                displayAll();
                break;
            case 4:
                displayDescending();
                break;
            case 5:
                displayLowestScore();
                break;
            case 6:
                cout << "Enter score to search: ";
                cin >> score;
                displaySameScore(score);
                break;
            case 7:
                cout << "Enter player name: ";
                cin >> name;
                displayBackwardFrom(name);
                break;
            case 0:
                cout << "Exiting program...?\n";
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 0);

    return 0;
}
