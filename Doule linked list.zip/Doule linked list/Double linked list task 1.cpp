#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

// ?? Function to create list from user input
void createList(int n) {
    Node* temp;
    Node* newNode;

    for (int i = 0; i < n; i++) {
        newNode = new Node();
        cout << "Enter mark " << i + 1 << ": ";
        cin >> newNode->data;
        newNode->next = NULL;
        newNode->prev = NULL;

        if (head == NULL)
            head = newNode;
        else {
            temp = head;
            while (temp->next != NULL)
                temp = temp->next;
            temp->next = newNode;
            newNode->prev = temp;
        }
    }
}

// ?? Display function
void display() {
    Node* temp = head;
    cout << "\nMarks in list: ";
    while (temp != NULL) {
        cout << temp->data << " <-> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}

// ?? (b) Add node at beginning
void addAtBeginning(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = head;

    if (head != NULL)
        head->prev = newNode;

    head = newNode;
}

// ?? (c) Add node after value 45
void addAfter45(int value) {
    Node* temp = head;
    while (temp != NULL && temp->data != 45)
        temp = temp->next;

    if (temp == NULL) {
        cout << "\nValue 45 not found!";
        return;
    }

    Node* newNode = new Node();
    newNode->data = value;

    newNode->next = temp->next;
    newNode->prev = temp;
    if (temp->next != NULL)
        temp->next->prev = newNode;
    temp->next = newNode;
}

// ?? (d) Delete node at beginning
void deleteAtBeginning() {
    if (head == NULL) {
        cout << "\nList is empty!";
        return;
    }
    Node* temp = head;
    head = head->next;
    if (head != NULL)
        head->prev = NULL;
    delete temp;
}

// ?? (e) Delete node after value 45
void deleteAfter45() {
    Node* temp = head;
    while (temp != NULL && temp->data != 45)
        temp = temp->next;

    if (temp == NULL || temp->next == NULL) {
        cout << "\nCannot delete after 45!";
        return;
    }

    Node* delNode = temp->next;
    temp->next = delNode->next;
    if (delNode->next != NULL)
        delNode->next->prev = temp;
    delete delNode;
}

int main() {
    int n;
    cout << "Enter number of marks: ";
    cin >> n;
    createList(n);
    display();

    cout << "\nAdding 99 at beginning...";
    addAtBeginning(99);
    display();

    cout << "\nAdding 77 after 45...";
    addAfter45(77);
    display();

    cout << "\nDeleting node at beginning...";
    deleteAtBeginning();
    display();

    cout << "\nDeleting node after 45...";
    deleteAfter45();
    display();

    return 0;
}
