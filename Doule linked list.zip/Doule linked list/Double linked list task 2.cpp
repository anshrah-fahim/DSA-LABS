#include <iostream>
using namespace std;

// Node structure for Doubly Linked List
struct Node {
    double data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

// ?? Function to create list with rainfall data for 7 days
void createRainfallList() {
    Node* temp;
    Node* newNode;
    double rainfall;

    for (int i = 1; i <= 7; i++) {
        do {
            cout << "Enter rainfall for day " << i << ": ";
            cin >> rainfall;
            if (rainfall < 0)
                cout << "Rainfall cannot be negative. Please re-enter.\n";
        } while (rainfall < 0);

        newNode = new Node();
        newNode->data = rainfall;
        newNode->next = NULL;
        newNode->prev = NULL;

        if (head == NULL)
            head = newNode;
        else {
            temp = head;
            while (temp->next != NULL)
                temp = temp->next;
            temp->next = newNode;
            newNode->prev = temp;
        }
    }
}

// ?? Function to display rainfall list
void display() {
    Node* temp = head;
    int day = 1;
    cout << "\nRainfall data:\n";
    while (temp != NULL) {
        cout << "Day " << day << ": " << temp->data << " mm\n";
        temp = temp->next;
        day++;
    }
}

// ?? Function to calculate total rainfall
double totalRainfall() {
    Node* temp = head;
    double total = 0;
    while (temp != NULL) {
        total += temp->data;
        temp = temp->next;
    }
    return total;
}

// ?? Function to find highest and lowest rainfall
void findHighLow(double &high, double &low, int &highDay, int &lowDay) {
    Node* temp = head;
    high = low = temp->data;
    highDay = lowDay = 1;
    int day = 1;

    while (temp != NULL) {
        if (temp->data > high) {
            high = temp->data;
            highDay = day;
        }
        if (temp->data < low) {
            low = temp->data;
            lowDay = day;
        }
        temp = temp->next;
        day++;
    }
}

// ?? Function to display rainfall after 5th node
void displayAfter5thNode() {
    Node* temp = head;
    int count = 1;

    while (temp != NULL && count < 5) {
        temp = temp->next;
        count++;
    }

    if (temp == NULL || temp->next == NULL)
        cout << "\nNo node exists after 5th day!\n";
    else
        cout << "\nRainfall of day after 5th node: " << temp->next->data << " mm\n";
}

int main() {
    cout << "??? Weekly Rainfall Tracker ???\n";
    createRainfallList();
    display();

    double total = totalRainfall();
    double avg = total / 7.0;

    cout << "\n-----------------------------------";
    cout << "\nTotal Rainfall for the Week: " << total << " mm";
    cout << "\nAverage Weekly Rainfall: " << avg << " mm";

    double high, low;
    int highDay, lowDay;
    findHighLow(high, low, highDay, lowDay);

    cout << "\nHighest Rainfall: " << high << " mm on Day " << highDay;
    cout << "\nLowest Rainfall: " << low << " mm on Day " << lowDay;
    cout << "\n-----------------------------------";

    displayAfter5thNode();

    cout << "\n";
    return 0;
}
