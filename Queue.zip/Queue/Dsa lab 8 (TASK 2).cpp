#include <iostream>
#include <queue>
#include <stack>
#include <string>
using namespace std;

class GarageSystem {
private:
    queue<int> road;     
    stack<int> garage;   

public:

    void On_road(int truck_id) {
        road.push(truck_id);
        cout << "Truck " << truck_id << " is now on the road.\n";
    }


    void Enter_garage(int truck_id) {
        if (road.empty()) {
            cout << "No trucks on the road to enter.\n";
            return;
        }

       
        if (road.front() == truck_id) {
            road.pop();
            garage.push(truck_id);
            cout << "Truck " << truck_id << " entered the garage.\n";
        } else {
            cout << "Truck " << truck_id << " is not at the front of the road.\n";
        }
    }

 
    void Exit_garage(int truck_id) {
        if (garage.empty()) {
            cout << "Garage is empty.\n";
            return;
        }

        if (garage.top() == truck_id) {
            garage.pop();
            cout << "Truck " << truck_id << " exited the garage.\n";
        } else {
            cout << "Truck is not near garage door (Truck " << truck_id << " cannot exit now).\n";
        }
    }


    void Show_trucks(string location) {
        if (location == "road") {
            if (road.empty()) {
                cout << "No trucks on the road.\n";
                return;
            }

            queue<int> temp = road;
            cout << "\nTrucks on road: ";
            while (!temp.empty()) {
                cout << temp.front() << " ";
                temp.pop();
            }
            cout << "\n";
        }

        else if (location == "garage") {
            if (garage.empty()) {
                cout << "Garage is empty.\n";
                return;
            }

            stack<int> temp = garage;
            cout << "\nTrucks in garage (top = nearest door): ";
            while (!temp.empty()) {
                cout << temp.top() << " ";
                temp.pop();
            }
            cout << "\n";
        }

        else {
            cout << "Invalid location! Use 'road' or 'garage'.\n";
        }
    }
};


int main() {
    GarageSystem system;

   
    system.On_road(101);
    system.On_road(102);
    system.On_road(103);
    system.Show_trucks("road");

 
    system.Enter_garage(101);
    system.Enter_garage(102);
    system.Enter_garage(103);
    system.Show_trucks("garage");

    
    system.Exit_garage(102);

  
    system.Exit_garage(103);
    system.Show_trucks("garage");

    
    system.Show_trucks("road");
    system.Show_trucks("garage");

    return 0;
}
