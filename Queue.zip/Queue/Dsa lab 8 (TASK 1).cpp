#include <iostream>
#include <string>
using namespace std;


struct ApplicantNode {
    int applicant_id;
    float height;
    float weight;
    string eyesight;
    string status;
    ApplicantNode* prev;
    ApplicantNode* next;

    ApplicantNode(int id, float h, float w, string e, string s) {
        applicant_id = id;
        height = h;
        weight = w;
        eyesight = e;
        status = s;
        prev = next = nullptr;
    }
};


class ApplicantQueue {
private:
    ApplicantNode* front;
    ApplicantNode* rear;

public:
    ApplicantQueue() {
        front = rear = nullptr;
    }

    
    void enqueue(ApplicantNode* applicant) {
        if (rear == nullptr) {
            front = rear = applicant;
        } else {
            rear->next = applicant;
            applicant->prev = rear;
            rear = applicant;
        }
        cout << "Applicant " << applicant->applicant_id << " added to the queue.\n";
    }

    
    void dequeue() {
        if (front == nullptr) {
            cout << "Queue is empty, no one to remove.\n";
            return;
        }
        ApplicantNode* temp = front;
        front = front->next;
        if (front)
            front->prev = nullptr;
        else
            rear = nullptr;
        cout << "Applicant " << temp->applicant_id << " has given the test and left the queue.\n";
        delete temp;
    }

    
    void removeFromPosition(int position) {
        if (front == nullptr) {
            cout << "Queue is empty.\n";
            return;
        }

        ApplicantNode* current = front;
        int count = 1;

        
        while (current != nullptr && count < position) {
            current = current->next;
            count++;
        }

        if (current == nullptr) {
            cout << "No applicant found at position " << position << ".\n";
            return;
        }

        
        if (current->prev != nullptr)
            current->prev->next = current->next;
        else
            front = current->next;  

        if (current->next != nullptr)
            current->next->prev = current->prev;
        else
            rear = current->prev;   

        cout << "Applicant " << current->applicant_id << " left the line due to urgency.\n";
        delete current;
    }

    
    void display() {
        if (front == nullptr) {
            cout << "Queue is empty.\n";
            return;
        }

        ApplicantNode* temp = front;
        cout << "\nCurrent Queue:\n";
        while (temp != nullptr) {
            cout << "[ID: " << temp->applicant_id
                 << ", Height: " << temp->height
                 << ", Weight: " << temp->weight
                 << ", Eyesight: " << temp->eyesight
                 << ", Status: " << temp->status << "]\n";
            temp = temp->next;
        }
        cout << "-----\n";
    }
};

int main() {
    ApplicantQueue queue;

    
    ApplicantNode* a1 = new ApplicantNode(1, 170, 65, "6/6", "Waiting");
    ApplicantNode* a2 = new ApplicantNode(2, 168, 70, "6/9", "Waiting");
    ApplicantNode* a3 = new ApplicantNode(3, 172, 68, "6/6", "Waiting");
    ApplicantNode* a4 = new ApplicantNode(4, 165, 60, "6/12", "Waiting");
    ApplicantNode* a5 = new ApplicantNode(5, 174, 75, "6/6", "Waiting");
    ApplicantNode* a6 = new ApplicantNode(6, 180, 80, "6/6", "Waiting");
    ApplicantNode* a7 = new ApplicantNode(7, 169, 62, "6/9", "Waiting");

    
    queue.enqueue(a1);
    queue.enqueue(a2);
    queue.enqueue(a3);
    queue.enqueue(a4);
    queue.enqueue(a5);
    queue.enqueue(a6);
    queue.enqueue(a7);

    queue.display();

    
    queue.removeFromPosition(2);
    queue.display();

    
    queue.dequeue();
    queue.display();

    
    ApplicantNode* a8 = new ApplicantNode(8, 178, 77, "6/6", "Waiting");
    queue.enqueue(a8);
    queue.display();

    return 0;
}
