#include <iostream>
#include <string>
using namespace std;

// Class representing a single node (book)
class Node {
public:
    string title;
    float price;
    int edition;
    int pages;
    Node* next;

    Node(string t, float p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
        next = nullptr;
    }
};

// Class representing the stack
class BookStack {
private:
    Node* top;  // pointer to top of stack

public:
    BookStack() {
        top = nullptr;
    }

    // Push new book onto the stack
    void push(string t, float p, int e, int pg) {
        Node* newNode = new Node(t, p, e, pg);
        newNode->next = top;
        top = newNode;
        cout << "Book \"" << t << "\" pushed to stack.\n";
    }

    // Pop top book from stack
    void pop() {
        if (isEmpty()) {
            cout << "Stack underflow! No books to pop.\n";
            return;
        }
        Node* temp = top;
        cout << "Book \"" << top->title << "\" popped from stack.\n";
        top = top->next;
        delete temp;
    }

    // Peek (display top element)
    void peek() {
        if (isEmpty()) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "\nTop Book Details:\n";
        cout << "Title: " << top->title << endl;
        cout << "Price: " << top->price << endl;
        cout << "Edition: " << top->edition << endl;
        cout << "Pages: " << top->pages << endl;
    }

    // Display all books in the stack
    void display() {
        if (isEmpty()) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "\n--- Books in Stack (Top to Bottom) ---\n";
        Node* temp = top;
        while (temp) {
            cout << "Title: " << temp->title
                 << ", Price: " << temp->price
                 << ", Edition: " << temp->edition
                 << ", Pages: " << temp->pages << endl;
            temp = temp->next;
        }
    }

    // Check if stack is empty
    bool isEmpty() {
        return top == nullptr;
    }
};

// Main function
int main() {
    BookStack stack;

    cout << "=== Push 5 Books into Stack ===\n";
    stack.push("Data Structures", 899.99, 3, 520);
    stack.push("Operating Systems", 1099.50, 2, 600);
    stack.push("C++ Programming", 750.25, 5, 450);
    stack.push("Artificial Intelligence", 1250.00, 4, 700);
    stack.push("Database Systems", 990.75, 3, 480);

    cout << "\n=== Find Top Book ===";
    stack.peek();

    cout << "\n=== Pop 2 Books ===\n";
    stack.pop();
    stack.pop();

    cout << "\n=== Remaining Books in Stack ===";
    stack.display();

    return 0;
}
