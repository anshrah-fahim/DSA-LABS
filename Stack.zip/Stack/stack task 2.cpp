#include <iostream>
using namespace std;

// ----------------------
// Inventory Class
// ----------------------
class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;

public:
    Inventory() {
        serialNum = 0;
        manufactYear = 0;
        lotNum = 0;
    }

    Inventory(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    void setValues(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    void display() const {
        cout << "Serial Number: " << serialNum
             << ", Year: " << manufactYear
             << ", Lot Number: " << lotNum << endl;
    }
};

// ----------------------
// Node Structure for Stack
// ----------------------
struct Node {
    Inventory data;
    Node* next;
};

// ----------------------
// Stack Class (Linked List Implementation)
// ----------------------
class Stack {
private:
    Node* top;

public:
    Stack() {
        top = nullptr;
    }

    // Push a new inventory item
    void push(const Inventory& item) {
        Node* newNode = new Node;
        newNode->data = item;
        newNode->next = top;
        top = newNode;
        cout << "Part added to inventory.\n";
    }

    // Pop top item
    void pop() {
        if (isEmpty()) {
            cout << "Inventory is empty! Nothing to remove.\n";
            return;
        }

        Node* temp = top;
        cout << "\nPart removed from inventory:\n";
        temp->data.display();
        top = top->next;
        delete temp;
    }

    // Display all items
    void displayAll() const {
        if (isEmpty()) {
            cout << "\nNo remaining parts in inventory.\n";
            return;
        }

        cout << "\nRemaining Parts in Inventory (Top to Bottom):\n";
        Node* temp = top;
        while (temp) {
            temp->data.display();
            temp = temp->next;
        }
    }

    bool isEmpty() const {
        return top == nullptr;
    }

    ~Stack() {
        while (!isEmpty()) {
            pop();
        }
    }
};

// ----------------------
// Main Function
// ----------------------
int main() {
    Stack inventoryStack;
    int choice;

    do {
        cout << "\n========= INVENTORY MENU =========\n";
        cout << "1. Add part to inventory (Push)\n";
        cout << "2. Remove part from inventory (Pop)\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            int serial, year, lot;
            cout << "Enter Serial Number: ";
            cin >> serial;
            cout << "Enter Year of Manufacture: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;

            Inventory newItem(serial, year, lot);
            inventoryStack.push(newItem);
        }
        else if (choice == 2) {
            inventoryStack.pop();
        }
        else if (choice == 0) {
            cout << "\nExiting Program...\n";
        }
        else {
            cout << "Invalid choice! Try again.\n";
        }

    } while (choice != 0);

    // Display remaining items before exiting
    inventoryStack.displayAll();

    return 0;
}
